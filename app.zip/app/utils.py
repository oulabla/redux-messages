import argparse 
import asyncio
import asyncpg
from asyncpg.pool import Pool

# // sudo /etc/init.d/postgresql restart
# DSN = 'postgresql://postgres@192.168.0.8:5432'
DSN = 'postgresql://postgres:root@localhost:5432/today'
# DSN_DB = DSN + '/today'


class DataBase:
    def __init__(self) -> None:
        self.pool: Pool = None
        self.listeners = []

    async def connect(self) -> Pool:
        self.pool = await asyncpg.create_pool(DSN)
        print("Connecting")
        return self.pool

    async def disconnect(self):
        if self.pool:
            releases = [
                self.pool.release(conn) for conn in self.listeners
            ]
            await asyncio.gather(*releases)
            await self.pool.close()

    async def __aenter__(self) -> Pool:
        return await self.connect()

    async def __aexit__(self, *exc):
        await self.disconnect()

    async def add_listener(self, channel, callback):
        conn: asyncpg.Connection = await self.pool.acquire()
        await conn.add_listener(channel, callback)
        self.listeners.append(conn)

    
