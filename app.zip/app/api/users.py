from functools import total_ordering
from aiohttp import web
from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy import func, inspect
from sqlalchemy.orm.strategy_options import subqueryload
from sqlalchemy.sql.expression import cast
from sqlalchemy.sql.functions import GenericFunction
from sqlalchemy.sql.sqltypes import DateTime, String
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.orm import selectinload
from sqlalchemy.dialects.postgresql import aggregate_order_by
from app.models import sql_engine
from app.models.role import Role
from app.models.user import User, role_assoc_table
from app.schemas.user_schema import UserSchema

async def delete_user(request: web.Request) -> web.Response:
    async_session = sessionmaker(
        sql_engine, expire_on_commit=False, class_=AsyncSession
    )
    id = int(request.match_info['id'])
    data = {}
    user_schema = UserSchema()
    async with async_session() as session:
        async with session.begin():
            result = await session.execute(select(User).filter_by(id=id))
            user = result.scalars().first()
            if user is None:
                raise web.HTTPNotFound()
            
            data = user_schema.dump(user)
            await session.delete(user)
            await session.flush()
            await session.commit()

    return web.json_response({
        "success": True,
        "data": data,        
    })


async def update_user(request: web.Request) -> web.Response:
    async_session = sessionmaker(
        sql_engine, expire_on_commit=False, class_=AsyncSession
    )
    body = await request.json()    
    if "name" not in body:
        raise web.HTTPBadRequest("No field name")
    name = body["name"]

    additional_info = ""
    if "additionalInfo" in body:
        additional_info = body["additionalInfo"]

    roles_id_list = []
    if "roles" in body:
        for role_data in body["roles"]:
            if "id" not in role_data:
                continue
            roles_id_list.append(role_data["id"])

    id = int(request.match_info['id'])

    user_schema = UserSchema()
    data = {}
    async with async_session() as session:
        async with session.begin():
            result = await session.execute(select(User).options(selectinload(User.roles)).filter_by(id=id))
            user = result.scalars().first()
            if user is None:
                raise web.HTTPNotFound()
            user.name = name
            user.additional_info = additional_info
            
            result = await session.execute(select(Role).filter(Role.id.in_(roles_id_list)))
            roles = result.scalars()

            user.roles.clear()
            for role in roles:
                user.roles.append(role)

            await session.flush()
            data = user_schema.dump(user)
            await session.commit()

    return web.json_response({
        "success": True,
        "data": data,        
    })



async def insert_user(request: web.Request) -> web.Response:
    async_session = sessionmaker(
        sql_engine, expire_on_commit=False, class_=AsyncSession
    )
    body = await request.json()    
    if "name" not in body:
        raise web.HTTPBadRequest("No field name")

    user_schema = UserSchema()
    data = {}
    async with async_session() as session:
        async with session.begin():
            user = User()
            user.name = str(body["name"])
            session.add(user)
            await session.flush()
            data = user_schema.dump(user)
            await session.commit()

    return web.json_response({
        "success": True,
        "data": data
    })


async def get_user(request: web.Request) -> web.Response: 
    id = int(request.match_info['id'])
    async_session = sessionmaker(
        sql_engine, expire_on_commit=False, class_=AsyncSession
    )
    user_schema = UserSchema()
    data = {}
    async with async_session() as session:
        async with session.begin():
            result = await session.execute(select(User).options(selectinload(User.roles)).filter_by(id=id))
            user = result.scalars().first()
            if user is None:
                raise web.HTTPNotFound()
            dump = user_schema.dump(user)
            data = dump
            await session.commit()


    return web.json_response({
        "data": data
    })

from sqlalchemy.orm import aliased

async def get_users(request: web.Request) -> web.Response:
    page = 1
    if "page" in request.rel_url.query:
        page = int(request.rel_url.query["page"])
    limit = 10
    if "limit" in request.rel_url.query:
        limit = int(request.rel_url.query["limit"])
    offset = (page - 1) * limit

    data = []
    total = 0

    async with sql_engine.connect() as conn:
        count_select = select(func.count(User.id)).select_from(User)
        cursor = await conn.execute(count_select)
        total = int(cursor.scalar())
        data_select = select(
            User.id, 
            User.name,
            func.string_agg(Role.name, ',').label('roles'),
        ).select_from(User).outerjoin(Role, User.roles).order_by(User.id).limit(limit).offset(offset).group_by(User.id)
        data_stream = await conn.stream(data_select)

        async for row in data_stream:
            record = {}
            for field_name in row.keys():
                record[field_name] = row[field_name]
                # print("row: %s" % (field_name, ))
                # print("row: %s" % (row, ))
            data.append(record)


    return web.json_response({
        "success": True,
        "data": data,
        "total": total,
    })

async def get_users_old(request : web.Request):
    page = 1
    if "page" in request.rel_url.query:
        page = int(request.rel_url.query["page"])
    limit = 10
    if "limit" in request.rel_url.query:
        limit = int(request.rel_url.query["limit"])
    offset = (page - 1) * limit

    async_session = sessionmaker(
        sql_engine, expire_on_commit=False, class_=AsyncSession
    )

    user_schema = UserSchema()
    data = []
    async with async_session() as session:
        async with session.begin():
            count_query = select(func.count("*")).select_from(User)
            cursor = await session.execute(count_query)
            total = int(cursor.scalar())
            stmt = select(User).limit(limit).offset(offset)            
            rows = await session.execute(stmt)
            for row in rows.scalars():
                dump = user_schema.dump(row)
                data.append(dump)
            await session.commit()

    return web.json_response({
        "success": True,
        "total": total,
        "data": data,        
    })