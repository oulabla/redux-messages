import asyncio
from aiohttp import web
from concurrent.futures import ThreadPoolExecutor
from urllib.request import urlopen
import random
import time
import aiohttp
import asyncpg
import datetime
from app.utils import DataBase
import uvloop
from app.models import sql_engine
from app.models.user import User

from app.api.users import get_users, get_user, insert_user, update_user, delete_user
from app.api.roles import get_roles, get_role, insert_role, update_role, delete_role

from app.middlewares import api_exception_json, api_underscore_body

db = DataBase()

def download_content():
    file = urlopen("http://127.0.0.1:8000/text")
    content = file.read()
    return content.decode('utf-8')

async def load_content():
    loop = asyncio.get_running_loop()
    future = loop.run_in_executor(ThreadPoolExecutor(), download_content)
    downloaded_content = await future
    return downloaded_content

async def fetch_external_content():
    async with aiohttp.ClientSession() as session:
        async with session.get("http://127.0.0.1:8000/text") as response:
            print(f'Status: {response.status}')
            html = await response.text()
    return html

async def index_action(request):
    loop = asyncio.get_running_loop()
    # async with Database
    res = await asyncio.gather(load_content(), fetch_external_content())
    content = f'res 1:{res[0]} res 2:{res[1]}'
    # print(res)
    return web.Response(text=content)

async def text_action(request):
    # await asyncio.sleep(2)
    rnd = random.randint(1, 100)
    return web.Response(text=str(rnd))

async def demo(conn: asyncpg.Connection):
    pk = await conn.fetchval("INSERT INTO users(name) VALUES('Valera') RETURNING id")
    print(pk)
    
async def db_test(request : web.Request):
    user_agent = request.headers['User-Agent']
    async with db as conn:
        try:
            pk = await conn.fetchval(f"INSERT INTO users(name) VALUES('{user_agent}') RETURNING id")
            print(pk)
        except Exception as e:
            print(e)
        
    return web.Response(text="db")

async def atest(request):
    async with sql_engine.begin() as conn:
        await conn
    return web.Response(text="lala")





app = web.Application(middlewares=[
    api_underscore_body,
    api_exception_json
])

app.router.add_get('/api/users', get_users)
app.router.add_get('/api/users/{id}', get_user)
app.router.add_post('/api/users', insert_user)
app.router.add_put('/api/users/{id}', update_user)
app.router.add_delete('/api/users/{id}', delete_user)

app.router.add_get('/api/roles', get_roles)
app.router.add_get('/api/roles/{id}', get_role)
app.router.add_post('/api/roles', insert_role)
app.router.add_put('/api/roles/{id}', update_role)
app.router.add_delete('/api/roles/{id}', delete_role)


app.router.add_get('/', index_action)
app.router.add_get('/text', text_action)
app.router.add_get('/db_test', db_test)
app.router.add_get('/atest', atest)


uvloop.install()

if __name__ == '__main__':
    
    web.run_app(app, port="8000")

